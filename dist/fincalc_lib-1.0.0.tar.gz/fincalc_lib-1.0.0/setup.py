from setuptools import setup, find_packages

setup(
    name="fincalc-lib",
    version="1.0.0",
    packages=find_packages(),
    description="Finance Analytics Calculator Library",
    author="Akansha Rana",
    python_requires='>=3.6',
)
